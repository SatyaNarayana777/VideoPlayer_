package com.example.videoplayer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(application: Application) : AndroidViewModel(application){

    var fullscreen = false
    val videoUrl = "https://videocdn.bodybuilding.com/video/mp4/62000/62792m.mp4"
}