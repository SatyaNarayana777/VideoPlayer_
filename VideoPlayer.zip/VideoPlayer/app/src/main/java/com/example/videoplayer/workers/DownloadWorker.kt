package com.example.videoplayer.workers

import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.hilt.work.HiltWorker
import androidx.work.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import android.os.Environment
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import com.example.videoplayer.R

@HiltWorker
class DownloadWorker @AssistedInject constructor (
    @Assisted val appContext: Context,
    @Assisted  workerParams: WorkerParameters
) : Worker(appContext, workerParams) {

    private val notificationManager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var notificationChannel = notificationManager.getNotificationChannel(CHANNEL_ID)
            if (notificationChannel == null) {
                notificationChannel = NotificationChannel(
                    CHANNEL_ID, TAG, NotificationManager.IMPORTANCE_LOW
                )
                notificationManager.createNotificationChannel(notificationChannel)
            }
        }
    }

    override fun doWork(): Result {

        createNotificationChannel()

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Downloading Video")
            .build()

        val foregroundInfo = ForegroundInfo(NOTIFICATION_ID, notification)
        setForegroundAsync(foregroundInfo)

        return downloadVideo()


    }

    private fun downloadVideo(): Result {

        val videoUrl =  inputData.getString("url")

        val request: DownloadManager.Request = DownloadManager.Request(Uri.parse(videoUrl))
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
        request.setTitle("download")
        request.setDescription("apk downloading")
        request.setAllowedOverRoaming(false)
        request.setDestinationUri(
            Uri.fromFile(
                File(
                    appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        .toString() + "/sample/", "video.mp4"
                )
            )
        )

        val downloadManager : DownloadManager? = appContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager?
        val downloadID: Long? = downloadManager?.enqueue(request)
        if(downloadID!=null){
            Log.d("DownloadId",downloadID.toString())
            setProgressAsync(Data.Builder().putBoolean("progress", true).build())
        }else{
            Log.d("DownloadFailes","failed")
            setProgressAsync(Data.Builder().putBoolean("progress", false).build())
        }
        return Result.success()
    }

    companion object {

        const val TAG = "ForegroundWorker"
        const val NOTIFICATION_ID = 101
        const val CHANNEL_ID = "Downloading video"
    }
}