package com.example.videoplayer.ui

import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.videoplayer.R
import com.example.videoplayer.viewmodel.MainViewModel
import com.example.videoplayer.workers.DownloadWorker
import com.google.android.exoplayer2.ExoPlayerFactory
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.upstream.DataSource
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util
import dagger.hilt.android.AndroidEntryPoint
import java.io.File
import com.google.android.exoplayer2.source.ExtractorMediaSource


@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val mainViewModel by viewModels<MainViewModel>()

    private val exoPlayer: SimpleExoPlayer by lazy {
        ExoPlayerFactory.newSimpleInstance(applicationContext)
    }
    private val playerView: PlayerView by lazy {
        findViewById(R.id.player)
    }
    private val fullScreenButton: ImageView by lazy {
        playerView.findViewById(R.id.exo_fullscreen_icon)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

            fullScreenButton.setOnClickListener {
                if (mainViewModel.fullscreen) {
                    fullScreenButton.setImageDrawable(
                        ContextCompat.getDrawable(
                            this@MainActivity,
                            R.drawable.ic_fullscreen_open
                        )
                    )
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                    if (supportActionBar != null) {
                        supportActionBar!!.show()
                    }
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    val params = playerView.getLayoutParams() as RelativeLayout.LayoutParams
                    params.width = ViewGroup.LayoutParams.MATCH_PARENT
                    params.height =
                        (200 * applicationContext.resources.displayMetrics.density).toInt()
                    playerView.setLayoutParams(params)
                    mainViewModel.fullscreen = false
                } else {
                    fullScreenButton.setImageDrawable(
                        ContextCompat.getDrawable(
                            this@MainActivity,
                            R.drawable.ic_fullscreen_close
                        )
                    )
                    window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
                    if (supportActionBar != null) {
                        supportActionBar!!.hide()
                    }
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    val params = playerView.getLayoutParams() as RelativeLayout.LayoutParams
                    params.width = ViewGroup.LayoutParams.MATCH_PARENT
                    params.height = ViewGroup.LayoutParams.MATCH_PARENT
                    playerView.setLayoutParams(params)
                    mainViewModel.fullscreen = true
                }
            }

        playerView.player = exoPlayer
        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT

        val dataSourceFactory: DataSource.Factory = DefaultDataSourceFactory(
            applicationContext, Util.getUserAgent(
                applicationContext, applicationContext.getString(R.string.app_name)
            )
        )

        val videoSource: MediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
            .createMediaSource(Uri.parse(mainViewModel.videoUrl))

        val myFile = File(
            this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                .toString() + "/sample/", "video.mp4"
        )

        val localVideoUrl = Uri.fromFile(myFile).toString()

        if(!myFile.exists()){
            exoPlayer.prepare(videoSource)

            val builder: Constraints.Builder = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)

            val data: Data.Builder = Data.Builder()
            data.putString("url", mainViewModel.videoUrl)

            val downloadWorkRequest = OneTimeWorkRequest.Builder(DownloadWorker::class.java)
                .addTag("Download")
                .setInputData(data.build())
                .setConstraints(builder.build())
                .build()

            WorkManager.getInstance(this).enqueue(downloadWorkRequest)

            WorkManager.getInstance(this).getWorkInfoByIdLiveData(downloadWorkRequest.id)
                .observe(this, { workInfo ->

                    if (workInfo!=null && workInfo.state.isFinished) {
                        when (workInfo.state) {
                            WorkInfo.State.SUCCEEDED -> {
                                if (workInfo.progress.getBoolean("progress",true)) {
                                    Toast.makeText(this,"Download Success",Toast.LENGTH_SHORT).show()
                                }else{
                                    Toast.makeText(this,"Download Failed",Toast.LENGTH_SHORT).show()
                                }
                            }
                            WorkInfo.State.FAILED -> {

                                Toast.makeText(this,"Download Failed",Toast.LENGTH_SHORT).show()

                            }
                            WorkInfo.State.CANCELLED -> {

                                Toast.makeText(this,"Download Canceled",Toast.LENGTH_SHORT).show()

                            }
                            else -> {

                            }
                        }
                    }

                })
        }else{
            val uri = Uri.parse(localVideoUrl)
            val mediaSource: MediaSource? = buildMediaSource(uri)
            exoPlayer.prepare(mediaSource)
        }

        //exoPlayer.prepare(videoSource)
        exoPlayer.playWhenReady = true

    }

    private fun buildMediaSource(uri: Uri): MediaSource? {
        return ExtractorMediaSource.Factory(
            DefaultDataSourceFactory(this, "Exoplayer-local")
        ).createMediaSource(uri)
    }

    override fun onPause() {
        super.onPause()
        exoPlayer.playWhenReady = false
    }

    override fun onDestroy() {
        exoPlayer.release()
        super.onDestroy()
    }
}